package Lecture;

class Node003
{
	int data;
	Node003 next;
	Node003(int data)
	{
		this.data=data;
		this.next=null;
	}
}

class LinkedList003
{
	Node003 head;
	LinkedList003()
	{
		head=null;
	}
	
	void insert(int data)
	{
		Node003 node=new Node003(data);
		if(head==null)
		{
			head=node;
		}
		else
		{
			Node003 temp=head;
			while(temp.next!=null)
			{
				temp=temp.next;
			}
			temp.next=node; // insert last
		}
	}
	
	void printList()
	{
		Node003 temp=head;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}
}

class MergeList
{
	Node003
	sortedMerge(Node003 headA , Node003 headB)
	{
		//dummy node
		
		Node003 dummyNode=new Node003(0);
		Node003 tail=dummyNode;
		
		while(true)
		{
			
			if(headA==null)
			{
				tail.next=headB;
				break;
			}
			
			if(headB==null)
			{
				tail.next=headA;
				break;
			}
			
			if(headA.data<=headB.data)
			{
				tail.next=headA;
				headA=headA.next;
			}
			else
			{
				tail.next=headB;
				headB=headB.next;
			}
			tail=tail.next;
		}
		return dummyNode.next;// new head
	}
}

public class MergeTwoLinkedList {

	public static void main(String[] args) {
		LinkedList003 list1=new LinkedList003();
		LinkedList003 list2=new LinkedList003();
		
		// 1st list
		list1.insert(5);
		list1.insert(10);
		list1.insert(15);
		
		//2nd list
		list2.insert(2);
		list2.insert(3);
		list2.insert(20);

		

        MergeList ml=new MergeList();
		list1.head=ml.sortedMerge(list1.head,list2.head);
		list1.printList();
	}

}
