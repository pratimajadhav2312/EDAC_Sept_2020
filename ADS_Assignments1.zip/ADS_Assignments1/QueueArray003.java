package Lecture;



public class QueueArray003 
{
	int front = 0;
	int capacity = 5;
	int size = 0;
	int rear = capacity - 1;
	int[] queue = new int[capacity];
	boolean isEmpty()
	{
		if(size == 0)
		{
			System.out.println("empty");
			return true;
		}
		else
			return false;
	}
	
	boolean isFull()
	{
		if(size == capacity)
		{
			System.out.println("full");
			return true;
		}
		else
			return false;
	}
	
	void enqueue(int item)
	{
		if(isFull())
			return;
		rear = (rear + 1) % capacity;
		queue[rear] = item;
		size = size + 1; 
		System.out.println(item + " is ENQUEUED ");
	}
	
	int dequeue()
	{
		if(isEmpty())
			return 0;
		int item = queue[front];
		front = (front + 1) % capacity;
		size = size - 1;;
		System.out.println(item + " is DEQUEUED ");
		return item;
	}
	
	public static void main(String[] args) 
	{
		QueueArray003 qa = new QueueArray003();
		qa.enqueue(15);
		qa.enqueue(20);
		qa.enqueue(30);
		qa.enqueue(40);
		qa.enqueue(50);
		
		qa.dequeue();
		qa.dequeue();
		qa.enqueue(60);
		qa.enqueue(70);
		qa.enqueue(80);
		qa.dequeue();
		qa.dequeue();
		qa.dequeue();
		qa.dequeue();
		qa.dequeue();
		qa.dequeue();
	}
}