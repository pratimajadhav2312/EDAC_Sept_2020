package Lecture;

class Node001
{
	int data;
	Node001 next;
}

class StackLinkedList
{
	Node001 top=null;
	void push(int data)
	{
		Node001 node=new Node001();
		node.data=data;
		node.next=top;
		
//		if(top==null)
//		{
			top=node;
//		}
//		else
//		{
//			node.next=top;
//			top=node;
//		}
	}

	void pop()
	{
		if(top==null)
		{
			System.out.println("stack is Empty");
		}
		else
		{
			System.out.println("Popped element is  : "+top.data+" ");
			top=top.next;
		}
		System.out.println();
	}
	
	
	void display()
	{
		System.out.println("Travarsal of node");
		Node001 temp=top;
		if(top==null)
		{
			System.out.println("Empty");
		}
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}
	
	void peek()
	{
		if(top==null)
		{
			System.out.println("Empty");
		}
		else
		{
			System.out.println("Top element is : "+top.data);
		}
	}
}

public class StackUsingLinkedList {

	public static void main(String[] args) {
		StackLinkedList sl=new StackLinkedList();
		 sl.push(10);
		 sl.push(20);
		 sl.push(30);
		 sl.push(40);
		 sl.display();
		 sl.pop();
		 sl.pop();
		 sl.peek();
		 sl.pop();
		 sl.pop();
		 sl.pop();
	}

}
