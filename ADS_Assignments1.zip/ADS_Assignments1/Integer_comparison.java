package Lecture;

import java.util.Scanner;

public class Integer_comparison {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	   

	}

}
