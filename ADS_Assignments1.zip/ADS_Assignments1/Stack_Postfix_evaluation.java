package Lecture;

class MyStack6
{
	
	
	int top;
	int max=100;
	int[] stack=new int[max];
	
	
	
	public MyStack6()
	{
		
		top =-1;
	}
	
	
	
	void push(int x)
	{
		if(top>=stack.length-1)
		{
			System.out.println("Stack overflow");
			
		}
		else
		{
			top++;
			stack[top]=x;
			System.out.println("pushed element is : "+stack[top]+"  "+top);
		}
	}
	
	
	int pop()
	{
		int item;
		if(top<0)
		{
			System.out.println("STack underflow");
			return 0;
		}
		else 
		{
			 item=stack[top];
			 top--;
			 System.out.println("Popped element is : "+item);
		     return item;
		}
	}
	
	public int peek()
	{
		if(top<0)
		{
			System.out.println("Error : top on empty stack");
		    return -1;
		}
		else
		{
			//System.out.println("peek element of the stack is : "+stack[top] + "and position of top is :"+top);;
		    return stack[top];
		}
	}
	

}
	  

class PostFixEvaluation
{
	MyStack6 s=new MyStack6();
	int PostEvaluation(String infix)
	{
		for(int i=0;i<infix.length();i++)
		{
			char c=infix.charAt(i);
			//System.out.println(c);
			if(c>='0' && c<='9')
			{
				s.push((int)c-'0');
			}
			
			else
			{
				int x=s.peek();
				s.pop();
				
				int y=s.peek();
				s.pop();
				
				if(c=='+')
				{
					s.push(y+x);
				}
				else if(c=='-')
				{
					s.push(y-x);
				}
				else if(c=='*')
				{
					s.push(y*x);
				}
				else
				{
					s.push(y/x);
				}
			}
		}
		
		
		
		return s.pop();
	}
}

public class Stack_Postfix_evaluation {

	public static void main(String[] args) 
	{
		Integer [] arr=new Integer[5];
		PostFixEvaluation pf=new PostFixEvaluation();
		//MyStack6<Integer> ms=new MyStack6<Integer>(arr);
	  // String infix="231*+9-";
		String infix="4*5/6+8-2*9/7";
		 //String infix="123+*";
	      System.out.println("Postfix evaluation ans is : "+pf.PostEvaluation(infix));;

	}

}
