package Lecture;

class Node004
{
	int data;
	Node004 next;
	
	Node004(int data)
	{
		this.data=data;
		next=null;
	}
}

class ReverseList
{
	Node004 head;
	
	void insertNode(int data)
	{
		//System.out.println("insert node fun");
		Node004 node=new Node004(data);
		if(head==null)
		{
			head=node;
			//System.out.println("added head");
		}
		else
		{
			Node004 temp=head;
			while(temp.next!=null)
			{
				temp=temp.next;
			}
			temp.next=node;
			//System.out.println("added");
		}
	}
	
	void printList()
	{
		System.out.println("print");
		Node004 temp=head;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
	}
	
	void reverse()
	{
		Node004 prev,current,nextnode;
		
		prev=null;
		
		current=nextnode=head;
		
		while(nextnode!=null)
		{
			nextnode=nextnode.next;
			current.next=prev;
			prev=current;
			current=nextnode;
		}
		head=prev;
	}
}
public class ReverseLinkedList {

	public static void main(String[] args) {
		ReverseList r=new ReverseList();
		r.insertNode(5);
		r.insertNode(6);
		r.insertNode(1);
		r.insertNode(7);
		r.printList();
		r.reverse();
		r.printList();
		

	}

}
