package Lecture;

class Node8
{
	int data;
	Node8 next;
	
	Node8(int data)
	{
		this.data=data;
		this.next=null;
	}
}

class SortLinked
{
	Node8 head;
	int length;
	
	SortLinked()
	{
		head=null;
		length=0;
	}
	
	void insertBeg(int data)
	{
	   Node8 node=new Node8(data);	
	   
	   if(head==null)
	   {
		   head=node;
	   }
	   else
	   {
		   node.next=head;
		   head=node;
	   }
	   length++;
	}
	
	void display()
	{
		Node8 node=head;
		
		while(node.next!=null)
		{
			System.out.print(node.data+" ");
			node=node.next;
		}
		System.out.print(node.data);
		System.out.println();
	}
	
	void sort()
	{
		int temp;
		Node8 p1,p2;
		p1=head;
		while(p1.next!=null)
		{
			p2=p1.next;
			while(p2!=null)
			{
				
				if(p1.data >p2.data)
				{
				 temp=p1.data;
				 p1.data=p2.data;
				 p2.data=temp;
				}
				p2=p2.next;
			}
			p1=p1.next;
		}
	}
	
	
}

public class SortingofLinkedList {

	public static void main(String[] args) 
	{
		SortLinked sl=new SortLinked();
		sl.insertBeg(15);
		sl.insertBeg(60);
		sl.insertBeg(5);
		sl.insertBeg(45);
		sl.insertBeg(25);
		
		sl.display();
		
		sl.sort();
		sl.display();
		
	}

}
