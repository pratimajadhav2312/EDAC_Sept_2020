package Lecture;

class Node002
{
   int data;
   Node002 next;
}

class Queue002
{
	Node002 front=null;
	Node002 rear=null;
	
	void enqueue(int data)
	{
		Node002 node=new Node002();
		node.data=data;
		node.next=null;
		
		if(front==null && rear==null)
		{
			front=rear=node;
		}
		else
		{
			rear.next=node;
			rear=node;
		}
	}
	
	void dequeue()
	{
		//Node002 temp=front;
		if(front==null && rear==null)
		{
			System.out.println("Empty");
		}
		else
		{
			System.out.println("Deleted element "+front.data);
			front=front.next;
			
		}
	}
	
	void peek()
	{
		if(front==null && rear==null)
		{
			System.out.println("empty");
		}
		else
		{
			System.out.println(front.data+" ");
		}
	}
	
	void display()
	{
		System.out.println("display function");
		Node002 temp;
		if(front==null && rear==null)
		{
			System.out.println("Empty");
		}
		else
		{
			temp=front;
		    while(temp!=null)
		    {
		    	System.out.print(temp.data+"  ");
		    	temp=temp.next;
		    }
	    System.out.println();
		}
	}
}

public class QueueUsingLinkedList {

	public static void main(String[] args) 
	{
		System.out.println("main");
		Queue002 q=new Queue002();
		q.enqueue(10);
		q.enqueue(20);
		q.enqueue(30);
		q.enqueue(40);
		q.display();
		q.dequeue();
		q.peek();

	}

}
