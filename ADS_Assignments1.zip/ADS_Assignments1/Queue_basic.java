package Lecture;
//linear Queue
class Queue2
{
	int front =-1;
	int rear = -1;
	int max=5;
	int arqueue[]=new int[max];
	
	void enqueue(int x)
	{
		if(!(rear==max-1))
		{
		
			rear++;
			arqueue[rear]=x;
			System.out.println("Que ele is : "+arqueue[rear]+"at rear"+rear);
			
			if(front==-1)
			{
				front=0;
			}

		}
		else
		{
			System.out.println("Full");
		}
	}
	
	void dqueue()
	{
		int val;
		if(rear==-1 || front>rear)
		{
			System.out.println("Queue is empty, Not allowed");
		}
		else
		{
			val=arqueue[front];
			System.out.println("Deleted ele is :"+val+"at front"+front);
			front++;
			System.out.println("front is :"+front);
		}
	}
}

public class Queue_basic {

	public static void main(String[] args) 
	{
		Queue2 q=new Queue2();
		q.enqueue(10);
		q.enqueue(20);
	    q.enqueue(30);
		q.enqueue(40);
		q.enqueue(50);
		q.enqueue(60);
		q.dqueue();
		q.dqueue();
		q.dqueue();
		q.dqueue();
		q.dqueue();
		q.dqueue();
	
		
	}

}
