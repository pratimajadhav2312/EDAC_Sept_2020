package Lecture;

import java.util.Scanner;

class BSTNode1
{
	BSTNode1 left;
	BSTNode1 right;
	int data;
	
	BSTNode1()
	{
		left=null;
		right=null;
		data=0;
	}
	
	BSTNode1(int n)
	{
		left=null;
		right=null;
		data=n;
	}
	
	int getData()
	{
		return data;
	}
	
	BSTNode1 getLeft()
	{
		return left;
	}
	
	BSTNode1 getRight()
	{
		return right;
	}
	
	void setLeft(BSTNode1 n)
	{
		left=n;
	}
	void setRight(BSTNode1 n)
	{
		right=n;
	}
}

class BST1
{
	BSTNode1 root;
	
	BST1()
	{
		root=null;
	}
	
	boolean search(int data)
	{
		return search(root,data);
	}
	
	boolean search(BSTNode1 node,int data)
	{
		boolean found=false;
	
		while((node!=null) && !found)
		{
			int val=node.getData();
			if(data<val)
			{
				node=node.getLeft();
			}
			else if(data>val)
			{
				node=node.getRight();
			}
			else
			{
				found=true;
				break;
			}
			found=search(node,data);	
		}
		return found;
		
	}
	
	boolean isEmpty()
	{
		return root==null;
	}
	
	public void insert(int data)
	{
	   root=insert(root,data);	
	}
	
	private BSTNode1 insert(BSTNode1 node, int data )
	{
		if(node==null)
		{
			node=new BSTNode1(data);
		}
		else
		{
			if(data<=node.getData())
			{
			   node.left=insert(node.getLeft(),data);   
			}
			else
			{
				node.right=insert(node.getRight(),data);
			}
		}
		 return node;
	}
	
	void delete(int data)
	{
		if(isEmpty())
		{
			System.out.println("Tree is empty");
		}
		else if(search(data)==false)
		{
			System.out.println("elemet not present");
		}
		else
		{
			root=delete(root,data);
		}
	}
	
	BSTNode1 delete(BSTNode1 node,int data)
	{
		BSTNode1 n,p,p2;
		if(root.getData()==data)
		{
			BSTNode1 lt,rt;
			lt=root.getLeft();
			rt=root.getRight();
			
			if(lt==null && rt==null)
			{
				return null;
			}
			else if(lt==null)
			{
				p=rt;
				return p;
			}
			else if(rt==null)
			{
				p=lt;
				return p;
			}
			else
			{
				p=rt;
				p2=rt;
				
				while(p.getLeft()!=null)
				{
					p=p.getLeft();
				}
				p.setLeft(lt);
				return p2;
			}
			
		}
		if(data<root.getData())
		{
			n=delete(root.getLeft(),data);
			root.setLeft(n);
		}
		else
		{
			n=delete(root.getRight(),data);
			root.setRight(n);
		}
			
		return root;	
			
	}
	
	void inorder()
	{
		inorder(root);
	}
	
	void inorder(BSTNode1 r)
	{
		if(r!=null)
		{
			inorder(r.getLeft());
			System.out.println(r.data + " ");
			inorder(r.getRight());
		}
			
	}
}

public class Tree_BST1 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		BST1 bst=new BST1();
        bst.insert(sc.nextInt());
        bst.insert(sc.nextInt());
        bst.insert(sc.nextInt());
        bst.insert(sc.nextInt());
        bst.insert(sc.nextInt());
        bst.inorder();
        bst.delete(12);
        bst.inorder();
        
	}

}
