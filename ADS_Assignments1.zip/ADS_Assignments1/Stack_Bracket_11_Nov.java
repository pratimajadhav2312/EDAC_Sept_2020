package Lecture;

class MyStack2
{
	private int max=5;
	int top;
	int[] stack=new int[max];
	
	public MyStack2()
	{
		top =-1;
	}

	void push(int x)
	{
		if(top>=max-1)
		{
			System.out.println("Stack overflow");
			
		}
		else
		{
			top++;
			stack[top]=x;
		}
	}
	
	void pop()
	{
		int item;
		if(top<0)
		{
			System.out.println("STack underflow");
			
		}
		else 
		{
			 item=stack[top];
			 top--;
		}
	}
	
	boolean isEmpty()
	{
		if(top<0)
		{
			//System.out.println("Stack is empty");
		     return true;
		}
		else
		{
			//System.out.println("Stack is not empty");
	        return false;
		}
	}
}
	  
class MyStack_Bracket
{
	//MyStack_Bracket[] mb=new MyStack_Bracket[];
	String str=" ";
	MyStack2 s;

	public MyStack_Bracket()
	{
		str="{}{}";	
		s=new MyStack2();
	}
	
	public int checkmatch()
	{
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)=='{')
			{
				s.push(1);
				
			}
			else if(str.charAt(i)=='}')
			{
				if(s.isEmpty())
				{
					
					System.out.println("Error : Too much closig para");
				     return -1;
				}
				else
				{
					s.pop();
					
				}
			}
		}
			if(s.isEmpty())
			{
				System.out.println("Balanced");
			    return 1;
			}
			else
			{
				System.out.println("Not balanced");
			    return 0;
			}
			
		}
	}


public class Stack_Bracket_11_Nov {

	public static void main(String[] args)
	{
		MyStack_Bracket bracket=new MyStack_Bracket();
	   bracket.checkmatch();
	}

}
