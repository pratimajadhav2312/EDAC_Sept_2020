package Lecture;

public class HeapInsert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
