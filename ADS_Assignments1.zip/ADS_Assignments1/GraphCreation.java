package Lecture;

import java.util.ArrayList;

class Graph
{
	ArrayList<ArrayList<Integer>> graph;
	int v;
	
	Graph(int nodes)
	{
		v=nodes;
		graph=new ArrayList<ArrayList<Integer>>(); //
		for(int i=0;i<v;i++)
		{
			graph.add(new ArrayList<Integer>());// add nodes 
		}
	}
	
	void addEdge(int v,int u)
	{
		graph.get(v).add(u); // undirected graph
		graph.get(u).add(v);
	}
	
	void printGraph()
	{
		for(int i=0;i<v;i++)
		{
			System.out.println("Node"+i);
			for(int x:graph.get(i))
				System.out.println("-> "+x);
			System.out.println();
		}
	}
	
}


public class GraphCreation {

	public static void main(String[] args) {
		Graph g=new Graph(5);
		g.addEdge(0, 1);
		g.addEdge(3, 2);
		g.addEdge(2, 4);
		g.addEdge(1, 4);
		g.addEdge(3, 1);
		g.addEdge(2, 0);
		g.printGraph();

	}

}
