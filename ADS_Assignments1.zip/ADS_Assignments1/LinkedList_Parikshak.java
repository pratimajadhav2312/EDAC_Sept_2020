package Parikshak;

import java.util.Scanner;

class Node
{
  int data;
  Node next;
  
  Node(int data)
  {
	this.data=data;
	this.next=null;
  }
}

class LinkedListFun
{
	 static int length;
	Node head;
	
	LinkedListFun()
	{
		length=0;
		head=null;
	}
	void add_node_at_last(int data)
	{
		Node node=new Node(data);
		//node.data=data;
		//node.next=null;
		
		if(head==null)
		{
			head=node;
		}
		else
		{
			Node n=head;
			while(n.next!=null)
			{
				n=n.next;
			}
			n.next=node;
		}
		length++;
		System.out.println("length beg"+length);
		
	}
	
	void add_node_at_first_pos(int data)
	{
		Node node=new Node(data);
		//node.data=data;
		//node.next=null;
		
		if(head==null)
		{
			head=node;
		}
		else
		{
			node.next=head;
			head=node;
		}
		length++;	
		System.out.println("length end"+length);
	
	}
	
	void addAfterNode(int value,int data)
	{
		Node newNode=new Node(data);
		Node preptr,ptr;
		preptr = ptr = head;
		
		while(preptr.data!=value && ptr!=null)
		{
			preptr=ptr;
			ptr=ptr.next;
		}
		
		newNode.next=preptr.next;
		preptr.next=newNode;
		
		
	}
	
	void addBeforeNode(int value,int data)
	{
		Node newNode=new Node(data);
		Node preptr,ptr;
		preptr=ptr=head;
		
		while(ptr.data!=value && ptr!=null)
		{
			preptr=ptr;
			ptr=ptr.next;
		}
		newNode.next=ptr;
		preptr.next=newNode;
		
	}
	
	void deleteNode(int d1)
	{
		
		Node preptr,ptr;
		preptr=ptr=head;
		while(ptr.data!=d1 && ptr!=null)
		{
			preptr=ptr;
			ptr=ptr.next;
		}
		preptr.next=ptr.next;
	}
	
	void deleteAfterNode(int value)
	{
		Node preptr,ptr;
		preptr=ptr=head;
		
		while(preptr.data!=value && ptr!=null)
		{
			preptr=ptr;
			ptr=ptr.next;
		}
		preptr.next=ptr.next;
		
	}
	
	void deleteBeforeNode(int value)
	{
		Node preptr,ptr;
		preptr=ptr=head;
		
		while(ptr.next.data!=value && ptr!=null)
		{
			preptr=ptr;
			ptr=ptr.next;
		}
		preptr.next=ptr.next;
		
	}
	
	
	
	
	
	void displayList()
	{
		Node node=head;
		while(node.next!=null)
		{
			System.out.print(node.data+" ");
			node=node.next;
		}
		System.out.print(node.data);
	}
	
	void fancyPrint()
	{
		Node node=head;
		while(node.next!=null)
		{
			System.out.print(node.data+"->");
			node=node.next;
		}
		System.out.print(node.data);
	}
	
	void reversePrint()
	{
		reversePrintM(head);
	}
	
	void reversePrintM(Node node)
	{
	   
		if(node==null)
		{
			return;
		}
		reversePrintM(node.next);
		System.out.print(node.data+" ");
		  
	}
	
	
}	
	
	
	
	
 public class LinkedList
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		LinkedListFun l1=new LinkedListFun();
		String status=" ";
		String ch=" ";
		int val=0,d1=0;
		do
		{
			System.out.println("enter choice");
		     ch=sc.next();
		     
		     switch(ch)
		     {
		       case "AB":
		    	     System.out.println("Enter data");
		    	     l1.add_node_at_first_pos(sc.nextInt());
		    	   break;
		    	   
		       case "PR":
		    	   l1.displayList();
		    	   break;
		    	   
		       case "AE":
		    	   System.out.println("Enter data");
		    	   l1.add_node_at_last(sc.nextInt());
		    	   break;
		    	   
		       case "AMA":
		    	   System.out.println("enter value aftr which elemst has to be add");
		    	    val=sc.nextInt();
		    	   System.out.println("enter data to be add");
		    	   d1=sc.nextInt();
		    	   l1.addAfterNode(val, d1);
		    	   break;
		    	   
		       case "AMB":
		    	   System.out.println("enter value BEFORE which elemst has to be add");
		    	    val=sc.nextInt();
		    	   System.out.println("enter data to be add");
		    	    d1=sc.nextInt();
		    	    l1.addBeforeNode(val, d1);
		    	   break;
		    	   
		       case "DN":
		    	   System.out.println("enter node to be delete");
		    	   l1.deleteNode(sc.nextInt());
		    	   break;
		    	   
		       case "DNA":
		    	   System.out.println("Enter node after which elemt has to be delete");
		    	   l1.deleteAfterNode(sc.nextInt());
		    	   break;
		    	   
		       case "DNB":
		    	   System.out.println("Enter node after which elemt has to be delete");
                   l1.deleteBeforeNode(sc.nextInt());
		    	   break;
		    	   
		       case "FPR":
		    	   l1.fancyPrint();
		    	   break;
		    	   
		       case "RPR":
		    	   l1.reversePrint();
		    	   break;
		    	   
		       default:
		    	   System.out.println("invalid");
		    	   break;
		    	   
		     }
		    
		}while(ch!="EXIT");
        //System.out.println("EXIT");
	}

}
