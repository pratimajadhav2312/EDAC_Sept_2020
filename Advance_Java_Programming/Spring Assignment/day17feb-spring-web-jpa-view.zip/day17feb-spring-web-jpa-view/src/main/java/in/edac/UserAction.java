package in.edac;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/user")
public class UserAction {

	@Autowired
	UserRepository userRepository;
	
	
	@GetMapping("/")
	public ModelAndView register() {
		ModelAndView mv = new ModelAndView("Register");
		
		return mv;
	}
	
	@PostMapping("/register")
	public ModelAndView createUser(User user) {
		userRepository.save(user);
		
		ModelAndView mv = new ModelAndView("Register");
		mv.addObject("q","1");
		
		return mv;
	}
	
	//try by me for exam practice
	
	@GetMapping("/login")
	public ModelAndView login() {
		ModelAndView mv = new ModelAndView("login");
		
		return mv;
	}
	
	@PostMapping("/login-action")
	public ModelAndView loginaction(User user) {
		User u = userRepository.findByUsernameAndPassword(user.getUsername(), user.getPassword());
		System.out.println(u);
		ModelAndView mv;
		if(u!=null) {
		 mv = new ModelAndView("home");
		 mv.addObject("my_auth","1");
		}
		else {
		 mv = new ModelAndView("login");
		}
		
		return mv;
	}
	
	
}
