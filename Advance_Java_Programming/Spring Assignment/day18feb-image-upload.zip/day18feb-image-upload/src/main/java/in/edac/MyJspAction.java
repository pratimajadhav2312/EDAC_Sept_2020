package in.edac;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;



@Controller
@RequestMapping("/my-jsp")
public class MyJspAction {

	
	@Autowired
	UserRepository userRepo;
	
	@GetMapping("/")
	public String firstJsp() {
		
		return "first";
	}
	
	@GetMapping("/register")
	public ModelAndView register() {
		ModelAndView mv = new ModelAndView("register");
		
		return mv;
	}
	
	@GetMapping("/second")
	public ModelAndView getImage() {
		ModelAndView mv = new ModelAndView("second");
		List<User> list = userRepo.findAll();
		
		mv.addObject("userList",list);
		
		return mv;
	}
	
	@PostMapping("/upload-demo-v2")
	public String fileUploadDemoV2(MultipartFile myfile,User user) {
		long randomNumber = System.currentTimeMillis();
		String storagePath = "/C:/Users/SAI/Desktop/CDAC_mumabi/Advance_Java/18-02-2021-image_uploa/";
		String destionPath = storagePath+randomNumber+".jpg";
		
		user.setProfileImage(randomNumber+".jpg");
		
		userRepo.save(user);
		
		// return "forward:/my-jsp/second" ;
		return "redirect:/my-jsp/second";
	
	}
	
	
}
