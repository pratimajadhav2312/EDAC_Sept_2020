package in.edac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day18febImageUploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day18febImageUploadApplication.class, args);
	}

}
