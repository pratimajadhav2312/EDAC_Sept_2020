package in.edac;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/my")
public class MyRestAction {

	
	@Autowired
	UserRepository userRepo;
	
	/**
	 * http://localhost:8080/my/
	 * @return
	 */
	@GetMapping("/")
	public String sayHi() {
	
		return "Hello";
	}
	

	/**
	 * http://localhost:8080/my/list
	 * @return
	 */
	
	@GetMapping("/list")
	public List<String> myList() {
		
		return Arrays.asList("pra","tu","ja","dha","v");
	}
	
	
	/**
	 * http://localhost:8080/my/upload-demo
	 * @return
	 * @throws IOException 
	 * @throws IllegalStateException 
	 */
	@PostMapping("/upload-demo")
	public String fileUploadDemo(MultipartFile myfile,String username)throws IllegalStateException, IOException 
	{
		
		System.out.println(myfile);
		
		myfile.transferTo(new File("C:/Users/SAI/Desktop/CDAC_mumabi/Advance_Java/18-02-2021-image_uploa/2.jpg"));
		
		return "demo"+username;
	}
	
	@PostMapping("/upload-demo-v1")
	public String fileUploadRestDemo(MultipartFile myfile,String username) throws IllegalStateException, IOException {
		 long randomNumber = System.currentTimeMillis();
		 String storagePath = "C:/Users/SAI/Desktop/CDAC_mumabi/Advance_Java/18-02-2021-image_uploa/";
		 
		 String destinationPath = storagePath+randomNumber+".jpg";
		 
		 myfile.transferTo(new File(destinationPath));
		 
		return "file upload"+username;
		
	}
	
	@PostMapping("/upload-demo-v2")
	public String fileUploadInRegister(MultipartFile myfile,User user) {
		long randomNumber = System.currentTimeMillis();
		String filePath = "C:/Users/SAI/Desktop/CDAC_mumabi/Advance_Java/18-02-2021-image_uploa/";
		String destination = filePath+randomNumber+".jsp";
		
		System.out.println(user);
		user.setProfileImage(randomNumber+".jpg");
		
		userRepo.save(user);
		
		return "done";
	}
}
	

