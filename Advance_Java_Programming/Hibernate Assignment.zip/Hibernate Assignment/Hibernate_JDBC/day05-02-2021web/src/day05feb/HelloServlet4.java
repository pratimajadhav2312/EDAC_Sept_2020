package day05feb;

import java.util.List;
import java.io.IOException;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/hello-servlet-4")
public class HelloServlet4 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<String> list = Arrays.asList("Delhi","Kolkata");
		
		request.setAttribute("list",list);
		
		//<jsp:forward/>
		request.getRequestDispatcher("hello-servlet-41").forward(request,response);
		
	}

}
