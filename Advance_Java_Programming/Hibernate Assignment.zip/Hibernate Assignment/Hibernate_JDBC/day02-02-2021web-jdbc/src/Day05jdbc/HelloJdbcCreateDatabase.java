




package Day05jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class HelloJdbcCreateDatabase {

	
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "edac20";

	
	public static void main(String[] args) throws Exception {

		Connection con = null;
		try {
			
		
			
			Class.forName(DB_DRIVER);
			
			 con = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
		
		   String sql = "CREATE DATABASE day02febdatabase";
		   
		   PreparedStatement ps =  con.prepareStatement(sql);
		   
		  ps.executeUpdate(); 
		  
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		finally
		{
			System.out.println("Finally Block executed");

			con.close();
		}
	}

}

