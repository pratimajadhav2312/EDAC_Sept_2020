package Day05jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class HelloJdbc5 {

	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/day02feb";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "edac20";

	public static void main(String[] args) throws Exception {

		Connection con = null;
		try {

			
			// Dynamic Loading!! the class Driver
			
			

			Class.forName(DB_DRIVER);

			con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

			String sql = "UPDATE USER_1 SET USERNAME='Anagha',EMAIL='anagha@gmailcom' WHERE ID=1";

			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.executeUpdate();

			System.out.println("Update Successfully");
		}

		catch (Exception e) {
			e.printStackTrace();
		} finally {
			con.close();
		}

	}

}
