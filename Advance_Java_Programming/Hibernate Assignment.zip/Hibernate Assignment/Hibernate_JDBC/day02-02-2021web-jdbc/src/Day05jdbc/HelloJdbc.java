package Day05jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class HelloJdbc {
	
	public static final String DB_URL ="jdbc:mysql://localhoat:3306/day02feb";
	public static final String DB_USER="root";
	public static final String DB_PASSWORD="edac20";
	

	public static void main(String[] args) {
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
		
			System.out.println("Horray!!! DB Connected!!");

			
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
