package edac.in;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HelloHibernate4 {

	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	public static void main(String[] args) {

		//create();
		
		//update();
		
		//delete();
		
		updateSpecificColumn();
	}
	
	
	public static void updateSpecificColumn() {
		Session session =  sessionFactory.openSession();
		Transaction tx =  session.beginTransaction();
		
		
		Person p = session.find(Person.class,4);
		
		p.setLastName("INDIA");
		
        session.update(p);
		
		tx.commit();
		session.close();
	}
	
	public static void delete() {
		Session session =  sessionFactory.openSession();
		Transaction tx =  session.beginTransaction();
		
		Person p = new Person();
		p.setId(6);
		
		session.delete(p);
		
		tx.commit();
		session.close();
	}
	
	public static void update() {
		Session session =  sessionFactory.openSession();
		Transaction tx =  session.beginTransaction();
		
        Person p = new Person();
        p.setId(1);
    	p.setFirstName("india");
		p.setMiddleName("bharat");
		p.setLastName("hindustan");
		
		session.update(p);
		
		tx.commit();
		session.close();
	}
	

	public static void create() {
		Session session = sessionFactory.openSession();
         Transaction tx = session.beginTransaction();
		
         Person p = new Person();
         p.setFirstName("dsjh");
         p.setMiddleName("atsdjul");
         p.setLastName("rakhdsuut");
         
         session.save(p);
         
         tx.commit();
		
		session.close();
	}
}
