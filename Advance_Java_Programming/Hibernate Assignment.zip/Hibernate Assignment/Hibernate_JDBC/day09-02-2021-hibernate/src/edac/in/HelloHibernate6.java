package edac.in;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HelloHibernate6 {

	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

	public static void main(String[] args) {
		//dqlDemo3();
		
		//dqlDemo();
		
		//dqlDemo1();
		
		dqlDemo2();
	
	}
	
	
	public static void dqlDemo() {
		Session session = sessionFactory.openSession(); 
		String sql = "SELECT * FROM USER";
		
		List<User> list = session.createNativeQuery(sql,User.class).getResultList();
	
	    list.stream().map(p->p.getUsername()).forEach(System.out::println);
	
	   session.close();
	}
	
	public static void dqlDemo1() {
		Session session = sessionFactory.openSession(); 

		String sql = "SELECT * FROM USER WHERE id=?";

		List<User> list = session.createNativeQuery(sql,User.class).setParameter(1,100).list();
		 
		list.stream().map(p->p.getEmail()).forEach(System.out::println);
		
		   session.close();
	}
	
	
	public static void dqlDemo2() {
		
	Session session =  sessionFactory.openSession();
	  String sql = "SELECT * FROM USER WHERE id=:id";
	  
	List<User> list = session.createNativeQuery(sql,User.class).setParameter("id",101).list();
	  
	list.stream().map(p->p.getUsername()).forEach(System.out::println);
	 session.close();
	}
	
	
	//DML : INSERT
	public  static void dqlDemo3() {
		Session session = sessionFactory.openSession(); 
		Transaction tx = session.beginTransaction();
	
		String sql = "INSERT INTO USER (id,username,email) VALUES (:id,:username,:email)";
		session.createNativeQuery(sql,User.class)
		.setParameter("id",101)
		.setParameter("username","INDIA")
		.setParameter("email","india@gmail.com")
		.executeUpdate();
	
		tx.commit();
		session.close();
	}

}
