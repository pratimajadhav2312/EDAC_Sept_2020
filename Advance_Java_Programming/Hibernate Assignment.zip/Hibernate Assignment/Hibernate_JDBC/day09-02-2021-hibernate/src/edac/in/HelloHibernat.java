package edac.in;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HelloHibernat {

	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

	public static void main(String[] args) {

	
	System.out.println("HBM2DDLL");
	
	}

}
