package day4;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class HelloDatabaseRead {
	
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/studentdatabase";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "edac20";

	public static void main(String[] args) {
	  try {
		  
		  Class.forName(DB_DRIVER);
		  
		 Connection con =  DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
		  
		 String sql = "SELECT * FROM STUDENT";
		 
		 PreparedStatement ps = con.prepareStatement(sql);
		 
		 ResultSet rs = ps.executeQuery();
		 
		 while(rs.next())
		 {
			int id = rs.getInt("studID");
			String name = rs.getString("name");
			
			System.out.println(id);
			System.out.println(name);
		 }
		 
		 con.close();
		 
	  }catch(Exception e) {
		  e.printStackTrace();
	  }

	}

}
