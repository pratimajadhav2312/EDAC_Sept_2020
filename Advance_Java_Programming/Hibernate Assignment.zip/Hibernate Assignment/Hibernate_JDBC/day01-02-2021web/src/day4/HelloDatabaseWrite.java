package day4;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Connection;

public class HelloDatabaseWrite {

	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/studentdatabase";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "edac20";
	
	public static void main(String[] args) {
		try
		{
			Class.forName(DB_DRIVER);
			
			Connection con = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
			
			String sql = "INSERT INTO `studentdatabase`.`student` (`name`) VALUES ('samaira');";
			
			PreparedStatement ps = con.prepareStatement(sql);
			
			int status = ps.executeUpdate();
			
			
			if(status!=0)
			{
				System.out.println("database was connected");
				System.out.println("Record was inserted");
			}
			else
			{
				System.out.println("not connected");
			}
			
			con.close();
			
		}catch(Exception e) {
		   e.printStackTrace();
		}
		

	}

}
