package in.edac;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HelloHibernate1 {

	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	
	public static void main(String[] args) {
		//updateDemo();
		
		//deleteDemo();
		
		//createDemo();
		
		//readSingleDemo();
		
		readAll();
		
	}
	
	
	public static void readAll() {
		Session session = sessionFactory.openSession();
		
		//HQL
		
	List<Student> list = session.createQuery("FROM Student",Student.class).list();
	 System.out.println(list);
	 
	 session.close();
	 
	}
	
	public static void readSingleDemo() {
		Session session = sessionFactory.openSession();
		
		Student std = session.find(Student.class,5);
	   
		System.out.println(std.getUsername());
		session.close();
	}
	
	
	public static void deleteDemo() {
		Session session = sessionFactory.openSession();
		
		Transaction tx = session.beginTransaction();
		
		Student std = new Student();
		
		std.setId(1);
		
		session.delete(std);
		
		tx.commit();
		session.close();
	}
	
	public static void updateDemo() {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		Student std = new Student();
		std.setId(1);
		std.setUsername("pratima");
		std.setPassword("jadhav");
		std.setEmail("pratima@gmailcom");
		std.setMobile("1234");
		
		session.update(std);
		
		tx.commit();
		session.close();
		
	}
	
	
	
	public static void createDemo() {
		Session session = sessionFactory.openSession();

		Transaction tx =  session.beginTransaction();
	   
		Student std = new Student();
		
		std.setUsername("Vishal");
		std.setPassword("djk");
		std.setEmail("vishal@jdashjk");
	
		// saving the state using hibernate
		System.out.println(std);
		session.save(std);
		
		tx.commit();
		
		session.close();
	}
	
	

}
