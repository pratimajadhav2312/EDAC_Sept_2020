package in.edac;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import in.edac.entity.Employee;
import in.edac.entity.Student;

public class HelloHibernet {

	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	
	public static void main(String[] args) {
		Session session = sessionFactory.openSession();

		//Transaction tx = session.beginTransaction();
		session.beginTransaction();
		
		Student std = new Student();
		std.setName("pratima");
		session.save(std);
		
		Employee emp = new Employee();
		emp.setDepartment("cse");
		session.save(emp);
	
		//tx.commit();
		session.getTransaction().commit();
		session.close();
	
	}

}
