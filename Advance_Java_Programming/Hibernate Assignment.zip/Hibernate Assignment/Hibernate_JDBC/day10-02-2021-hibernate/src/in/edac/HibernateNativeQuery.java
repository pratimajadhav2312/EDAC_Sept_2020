package in.edac;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import in.edac.entity.Student;

public class HibernateNativeQuery {

	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	public static void main(String[] args) {

		//demo1();
		//demo2();
		//demo3();
		//demo4();
  	//demo5();
		//demo6();
		//demo7();
		demo8();
	}
	
	
	public static void demo8() {
		Session session = sessionFactory.openSession();
	  
		
		String sql = "SELECT * FROM STUDENT WHERE id=:id";

		Student stud =  session.createNativeQuery(sql,Student.class)
							.setParameter("id",6)
							.getSingleResult();
		
		System.out.println(stud);
		
		session.close();
	
	}
	
	public static void demo7() {
		Session session = sessionFactory.openSession();
	  
		
		String sql = "SELECT * FROM STUDENT WHERE id=:id";

		List<Student> list = session.createNativeQuery(sql,Student.class)
							.setParameter("id",6)
							.list();
		
		Student stud = list.get(0);
		System.out.println(stud);
		
		session.close();
	
	}
	
	public static void demo6() {
		Session session = sessionFactory.openSession();
	   session.beginTransaction();
		
		String sql = "DELETE FROM STUDENT WHERE id=:id";

		session.createNativeQuery(sql)
							.setParameter("id",5)
							.executeUpdate();
		
		session.getTransaction().commit();
		
		session.close();
	
	}
	
	public static void demo5() {
		Session session = sessionFactory.openSession();
	   session.beginTransaction();
		
		String sql = "UPDATE STUDENT SET name=:name where id=:id";

		session.createNativeQuery(sql)
							.setParameter("name","shree")
							.setParameter("id",3)
							.executeUpdate();
		
		session.getTransaction().commit();
		
		session.close();
	
	}
	
	public static void demo4() {
		Session session = sessionFactory.openSession();
	   session.beginTransaction();
		
		String sql = "INSERT INTO STUDENT (name,email,mobile) VALUES (:name,:email,:mobile)";

		session.createNativeQuery(sql)
							.setParameter("name","shreya")
							.setParameter("email","shreya@gmail.com")
							.setParameter("mobile",1233)
							.executeUpdate();
		
		session.getTransaction().commit();
		
		session.close();
	
	}
	
	public static void demo3() {
		Session session = sessionFactory.openSession();
	
		String sql = "SELECT * FROM STUDENT WHERE id=:id AND name=:name";
		List<Student> list = session.createNativeQuery(sql,Student.class).setParameter("id",3).setParameter("name","sahil").list();
		
		list.stream().map(Student::getEmail).forEach(System.out::println);
		
		session.close();
	
	}

	
	public static void demo2() {
		Session session = sessionFactory.openSession();
	
		String sql = "SELECT * FROM STUDENT WHERE id=? AND name=?";
		List<Student> list = session.createNativeQuery(sql,Student.class).setParameter(1,4).setParameter(2,"punam").list();
		
		list.stream().map(Student::getName).forEach(System.out::println);
		
		session.close();
	
	}

	public static void demo1() {
		Session session = sessionFactory.openSession();
	
		String sql = "SELECT * FROM STUDENT";
		List<Student> list = session.createNativeQuery(sql,Student.class).list();
		
		list.stream().map(Student::getName).forEach(System.out::println);
		
		session.close();
	
	}
}
