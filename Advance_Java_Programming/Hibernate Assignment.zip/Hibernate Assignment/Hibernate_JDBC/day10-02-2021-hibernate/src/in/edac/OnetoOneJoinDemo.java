package in.edac;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import in.edac.entity.Address;
import in.edac.entity.Student;



public class OnetoOneJoinDemo {

	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	
	public static void main(String[] args) {

		//createOneToOneRecord();
		readRecord();
	}

	public static void readRecord() {
		Session session = sessionFactory.openSession();

		Student st = session.find(Student.class,8);
		System.out.println(st);
		
		session.close();
	}
	
	public static void createOneToOneRecord() {
		Session session = sessionFactory.openSession();

		session.beginTransaction();
		
		Student s1 = new Student("aysha","aisha@gmail.com","2135");
		Address a1 = new Address("Kharghar","MH");
		
		s1.setAddress(a1);
		
		session.save(s1);
		session.save(a1);
		
		session.getTransaction().commit();
		session.close();
	}
}
