package day04feb;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Helloservlet5
 */


// here servlet programming is running bcz we write <servlet></servlet> in "web.xml" file
public class Helloservlet5 extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
	{
		
		try {
			PrintWriter out = response.getWriter();
			
			out.println("server-55");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
