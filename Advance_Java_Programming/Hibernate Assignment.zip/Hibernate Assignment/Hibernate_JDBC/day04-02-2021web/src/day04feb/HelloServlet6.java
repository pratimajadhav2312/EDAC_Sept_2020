package day04feb;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HelloServlet6
 */
@WebServlet("/servlet-6")
public class HelloServlet6 extends HttpServlet {

	@Override
	public void init() throws ServletException {
		System.out.println("Object Initialized!!!");
	}


	public void doGet(HttpServletRequest request,HttpServletResponse response)
	{
		
		try {
			System.out.println("I am new version of service method");

			PrintWriter out = response.getWriter();
			out.println("servlet--6");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	@Override
	public void destroy() {
		System.out.println("Object Destroyed!!!");
	}


}
