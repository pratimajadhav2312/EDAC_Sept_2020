package in.edac.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import in.edac.dao.User;

/**
 * CRUD
 * 
 * createUser/addUser/insertUser
 */



public class StepByStepDao {
	
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/advanceJava";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "edac20";
	
	
	public void checkConnectionOld() {
		try {
			Class.forName(DB_DRIVER);
			
			Connection con = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
			
			con.close();
			
			System.out.println("Success");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	


	
	public void checkConnection() {
		try(Connection con = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);){
         
			Class.forName(DB_DRIVER);
			
			System.out.println("Success try with resourses");
			
			
		}catch(Exception e) {
			
		}
	}
	
	
	public boolean createUserV1() {

		
		try(Connection con = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);){
       
			Class.forName(DB_DRIVER);
			
			String sql = "INSERT INTO USER (USERNAME,PASSWORD,EMAIL,MOBILE) VALUES (?,?,?,?)";
			
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setString(1,"pratima");
			ps.setString(2,"pratima@gmail.com");
			ps.setString(3,"pratima23");
			ps.setString(4,"123456789");
			
			ps.executeUpdate();
			
			System.out.println("Insert Success");
			
			return true;
		}catch(Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	
	public boolean createUser(User user) {
		
		try(Connection con = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);){
			
			Class.forName(DB_DRIVER);
			
			String sql = "INSERT INTO USER (USERNAME,PASSWORD,EMAIL,MOBILE) VALUES (?,?,?,?)";
			
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setString(1,user.getUsername());
			ps.setString(2,user.getPassword());
			ps.setString(3,user.getEmail());
			ps.setString(4,user.getMobile());
			
			ps.executeUpdate();
			
			System.out.println("Insert Succcessfully");
			
			return true;
			
		}catch(Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public static void main(String[] args) {
		StepByStepDao dao = new StepByStepDao();
		
      //dao.checkConnectionOld();
		
		//dao.checkConnection();
		
		//dao.createUserV1();
		
		User user = new User("ajju","poo@gmail.com","sda","23551");
		//dao.createUser(user);
	
	}

}
