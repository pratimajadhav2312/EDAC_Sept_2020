package in.edac.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UserDao {

	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/advanceJava";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "edac20";
	
	public void checkConnection()  {
		try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);) {
			
			System.out.println("Success Try With Resource!!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public boolean CreateUser(User user) throws Exception {
		
		Class.forName(DB_DRIVER);
		try(Connection con = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);){
			
			String sql = "INSERT INTO USER (USERNAME,PASSWORD,EMAIL,MOBILE) VALUES (?,?,?,?)";
			
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setString(1,user.getUsername());
			ps.setString(2,user.getPassword());
			ps.setString(3,user.getEmail());
			ps.setString(4,user.getMobile());
			
			ps.executeUpdate();
			
			System.out.println("Insert Successss");
			
			return true;
			
		}catch(Exception e) {
			e.printStackTrace();
			//return false;
			throw e;
		}
	}
	
	
      public boolean updateUser(User user) throws Exception {
		
		Class.forName(DB_DRIVER);
		try(Connection con = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);){
			
			String sql = "UPDATE USER SET USERNAME=?,PASSWORD=?,EMAIL=?,MOBILE=? WHERE ID=?";
			
			
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setString(1,user.getUsername());
			ps.setString(2,user.getPassword());
			ps.setString(3,user.getEmail());
			ps.setString(4,user.getMobile());
            ps.setInt(5,user.getId());
			
			ps.executeUpdate();
			
			System.out.println("Update Successss");
			
			return true;
			
		}catch(Exception e) {
			e.printStackTrace();
			//return false;
			throw e;
		}
	}
	
      
      public boolean deleteUser(User user) throws Exception {
  		
  		Class.forName(DB_DRIVER);
  		try(Connection con = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);){
  			
  			String sql = "DELETE FROM USER WHERE ID=?";
  			
  			
  			PreparedStatement ps = con.prepareStatement(sql);
  			
              ps.setInt(1,user.getId());
  			
  			ps.executeUpdate();
  			
  			System.out.println("delete Successss");
  			
  			return true;
  			
  		}catch(Exception e) {
  			e.printStackTrace();
  			//return false;
  			throw e;
  		}
  	}
      
      public List<User> readAllUser() throws Exception {
    		
    		Class.forName(DB_DRIVER);
    		try(Connection con = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);){
    			
    			String sql = "SELECT * FROM USER";
    			
    			
    			PreparedStatement ps = con.prepareStatement(sql);
    			
                ResultSet rs = ps.executeQuery();
                
                List<User> list = new ArrayList<User>();
                
                while(rs.next()) {
                	// ROW :: Reading columns of row
                	
                	int colId = rs.getInt("ID");
                	String colUsername = rs.getString("USERNAME");
                	String colEmail = rs.getString("EMAIL");
                	String colMobile = rs.getString("MOBILE");
                	
                	// ROW :: User We are conveting the row into User object
                	
                	User user = new User();
                	
                	user.setId(colId);
                	user.setUsername(colUsername);
                	user.setEmail(colEmail);
                	user.setMobile(colMobile);
                	
                	//Add row/user to list
                	list.add(user);
                	
                	
                }
    			
    			
    	
    			return list;
    			
    		}catch(Exception e) {
    			e.printStackTrace();
    			//return false;
    			throw e;
    		}
    	}
 //========================================================================     
      
 public User readSingleUser(int id) throws Exception {
    	  Class.forName(DB_DRIVER);
    	  
    	  User u=null;
 		try(Connection con = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);){
			
			String sql = "SELECT * FROM USER WHERE ID=?";
 			
			PreparedStatement ps = con.prepareStatement(sql);
  			ps.setInt(1,id);
             ResultSet rs = ps.executeQuery();
              
             while(rs.next()) {
             
            	 u=new User();
             	
            	 u.setId(rs.getInt("id"));
            	 u.setUsername(rs.getString("username"));
            	 u.setPassword(rs.getString("password"));
            	 u.setEmail(rs.getString("email"));
            	 u.setMobile(rs.getString("mobile"));
             }
             
 		}catch(Exception e) {
			e.printStackTrace();
			//return false;
 			throw e;
 		} 
 		
 		return u;
      }
      
      
      //===============================================================
	
	public static void main(String[] args) throws Exception  {

		UserDao dao = new UserDao();
		//dao.checkConnection();
		
		//INSER USER
		
		//User user = new User("Praj","parj@gmail.com","jdsg","12345");
		//dao.CreateUser(user);
		
		
		
		//UPDATE USER
		
        //User user = new User("Prajuuu","parjuuu@gmail.com","jdsg","12345");
		//user.setId(3);
		//dao.updateUser(user);
		
		//DELETE USER
		
		//User user = new User();
		//user.setId(3);
		//dao.deleteUser(user);
		
		
		//READ USER
		
		List<User> list = dao.readAllUser();
		System.out.println(list);	
		
	}

}
