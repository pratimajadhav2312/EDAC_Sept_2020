package in.dao.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.edac.dao.User;
import in.edac.dao.UserDao;

/**
 * Servlet implementation class Update
 */
@WebServlet("/update")
public class Update extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			System.out.println("===========");
		String str = request.getParameter("id");
		int id = Integer.parseInt(str);
		
		
		UserDao dao = new UserDao();
		User u = dao.readSingleUser(id);
		
		System.out.println("==================");
		System.out.println(u.getId());
		System.out.println(u);
		System.out.println("==================");
		
		
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-read");
		
		request.setAttribute("updateList",u);
		
		dispatcher.forward(request,response);
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
	}

}
